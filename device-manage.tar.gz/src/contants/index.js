

export  const FILE_UPLOAD_URL='http://8.130.105.216:8086/device/upload/file'
